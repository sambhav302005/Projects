package com.example.igp

object Constants {

    val apiKey = "AIzaSyAKTVlGQVVbPnVRdNXE8NfS6jANshPmBmQ"
}