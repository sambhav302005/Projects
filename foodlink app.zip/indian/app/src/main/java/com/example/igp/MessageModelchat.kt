package com.example.igp

data class MessageModelchat(
    val message : String,
    val role : String,
)
